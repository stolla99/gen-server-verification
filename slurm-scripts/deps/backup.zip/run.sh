#!/bin/bash

TARGETDIR="model"
PREFIX="tlc_large_"

SPECS=("$@")
if [ ${#SPECS[@]} -eq 0 ]; then
	SPECS=("P" "S" "SE" "T")
fi
# echo ${SPECS[@]} 

for SPEC in "${SPECS[@]}"; do
	echo "Running TLC on $SPEC properties"
	
	# Setup jobs copy files to exclude conflicting state files
	DIR=($PREFIX$SPEC)
	mkdir -p $DIR/

	# Copy files
	cp gen_server_behaviour_simple.tla ./$DIR/
	cp GenServerUtil.tla ./$DIR/
	cp ShiVizExt.tla ./$DIR/
	cp $DIR.bat ./$DIR/
	cd $DIR/	

	# Remove .err and .out files (old)
	rm -f *.out *.err

	# Start job
	sbatch $DIR.bat
	cd -
done
